public interface Countable {
    void count();
}
