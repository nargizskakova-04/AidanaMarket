import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Sweets snickers = new Sweets(101, "Snickers", 4500, 0);
        Sweets alpenGold = new Sweets(102, "Alpen Gold", 3000, 0);
        Sweets barbaris = new Sweets(103, "Barbaris", 1000, 0);
        Sweets polet = new Sweets(104, "Polet", 1200, 0);
        Sweets milka = new Sweets(105, "Milka", 5000, 0);

        Meat beef = new Meat(201, "Beef", 5000, 0);
        Meat chicken = new Meat(202, "Chicken", 3000, 0);
        Meat turkey = new Meat(203, "Turkey", 6000, 0);
        Meat bear = new Meat(204, "Bear", 25000, 0);
        Meat rabbit = new Meat(205, "Rabbit", 3000, 0);

        Fruit apple = new Fruit(301, "Apple", 500, 0);
        Fruit orange = new Fruit(302, "Orange", 2000, 0);
        Fruit pineapple = new Fruit(303, "Pineapple", 3000, 0);
        Fruit banana = new Fruit(304, "Banana", 1050, 0);
        Fruit melon = new Fruit(305, "Melon", 1500, 0);

        Bakery bread = new Bakery(401, "Bread", 150, 0);
        Bakery bagels = new Bakery(402, "Bagels", 240, 0);
        Bakery buns = new Bakery(403, "Buns", 270, 0);
        Bakery rolls = new Bakery(404, "Rolls", 160, 0);
        Bakery cake = new Bakery(405, "Cake", 4000, 0);

        Milk milk = new Milk(501, "Milk", 450, 0);
        Milk butter = new Milk(502, "Butter", 2000, 0);
        Milk cheese = new Milk(503, "Cheese", 2500, 0);
        Milk airan = new Milk(504, "Airan", 400, 0);
        Milk yogurt = new Milk(505, "Yogurt", 200, 0);


        ArrayList<Sweets> sweets = new ArrayList<>(); //change
        sweets.add(snickers);
        sweets.add(alpenGold);
        sweets.add(barbaris);
        sweets.add(polet);
        sweets.add(milka);


        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("\nYou have the following available functions:");
            System.out.println("1) To order a products");
            System.out.println("2) To edit a cart");
            System.out.println("3) To finish");
            System.out.print("Choose a function: ");
            String input = scanner.nextLine();
            switch (input) {
                case "1":
                    System.out.println("1)Sweets" + "\n" + "2)Meat" + "\n" + "3)Fruit" + "\n" + "4)Bakery" + "\n" + "5)Milk");
                    System.out.print("Choose a product department: ");
                    String input1 = scanner.nextLine();
                    switch (input1) {
                        case "1":
                            printDataS(sweets);
                            //массив со всеми продуктами из "Sweets"
                        case "2":
                            //массив со всеми продуктами из "Meat"
                        case "3":
                            //массив со всеми продуктами из "Fruit"
                        case "4":
                            //массив со всеми продуктами из "Bakery"
                        case "5":
                            //массив со всеми продуктами из "Milk"
                    }
                case "2":

            }
        }
    }
   public static void printDataS(ArrayList<Sweets> sweets){
        for(Product product : sweets){
            System.out.println(product.toString());
        }
    }
}