public class Sweets extends Product{
        private double weightS;

        public Sweets(int id, String name, double price, double weightS){
                super(id, name, price);
                this.weightS = weightS;
        }
        public Sweets(){

        }

        public double getWeightS() {
                return weightS;
        }
        public void setWeightS(double weightS) {
                this.weightS = weightS;
        }

        @Override
        public void count(){
                System.out.println("The price is " + getPrice()*getWeightS());
        }

        @Override                       //change
        public String toString(){
                return (getId() + " " + getName() + " " + getPrice() + " " + getWeightS());
        }
}
